from __future__ import annotations

import ast
import hashlib
import json
import shutil
import string
from datetime import datetime
from pathlib import Path


PACKAGE_DIR = Path(__file__).parent.resolve()
CONFIG_PATH = Path.home() / ".ahip-devkit.json"
KNOWN_REPOS = (
    Path(r"Y:\R&D\Infra-signal"),
    Path(r"\\192.168.0.147\1. AllenHammettInc\R&D\Infra-signal"),
)


def is_repo(path: Path) -> bool:
    return (
        path.exists()
        and (path / "app.py").is_file()
        and (path / "engines").is_dir()
        and (path / "README.md").is_file()
    )


def find_repo() -> Path:
    candidates: list[Path] = []

    if CONFIG_PATH.exists():
        try:
            saved = json.loads(CONFIG_PATH.read_text(encoding="utf-8")).get("repository")
            if saved:
                candidates.append(Path(saved))
        except Exception:
            pass

    candidates.extend(KNOWN_REPOS)
    candidates.extend([Path.cwd(), PACKAGE_DIR])

    for start in (Path.cwd(), PACKAGE_DIR):
        current = start.resolve()
        while True:
            candidates.append(current)
            if current == current.parent:
                break
            current = current.parent

    for letter in string.ascii_uppercase:
        root = Path(f"{letter}:\\")
        if root.exists():
            candidates.extend(
                [
                    root / "R&D" / "Infra-signal",
                    root / "infra-signal",
                    root / "GitHub" / "infra-signal",
                ]
            )

    seen = set()
    for candidate in candidates:
        key = str(candidate).lower()
        if key in seen:
            continue
        seen.add(key)
        if is_repo(candidate):
            return candidate.resolve()

    raise SystemExit("AHIP repository not found.")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    repo = find_repo()
    manifest = json.loads((PACKAGE_DIR / "manifest.json").read_text(encoding="utf-8"))
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backup_root = repo / "backups" / f"executive_engine_{timestamp}"
    log_root = repo / "logs"
    backup_root.mkdir(parents=True, exist_ok=True)
    log_root.mkdir(parents=True, exist_ok=True)

    installed = updated = skipped = 0
    records = []

    print("=" * 60)
    print("AHIP Executive Engine Installer")
    print("=" * 60)
    print("Repository:", repo)
    print()

    for item in manifest["files"]:
        src = PACKAGE_DIR / item["source"]
        dst = repo / item["destination"]
        dst.parent.mkdir(parents=True, exist_ok=True)

        if dst.exists():
            if sha256(src) == sha256(dst):
                print("[SKIP]", item["destination"])
                skipped += 1
                records.append({"file": item["destination"], "action": "skipped"})
                continue
            backup = backup_root / item["destination"]
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dst, backup)
            updated += 1
            action = "updated"
        else:
            installed += 1
            action = "installed"

        shutil.copy2(src, dst)

        if dst.suffix == ".py":
            ast.parse(dst.read_text(encoding="utf-8"))

        print("[OK]", item["destination"], f"({action})")
        records.append({"file": item["destination"], "action": action})

    CONFIG_PATH.write_text(
        json.dumps({"repository": str(repo)}, indent=2),
        encoding="utf-8",
    )

    log = {
        "package": manifest["package_name"],
        "version": manifest["package_version"],
        "repository": str(repo),
        "installed": installed,
        "updated": updated,
        "skipped": skipped,
        "records": records,
    }
    (log_root / f"executive_engine_{timestamp}.json").write_text(
        json.dumps(log, indent=2),
        encoding="utf-8",
    )

    print()
    print("Installation complete.")
    print("Installed:", installed)
    print("Updated:", updated)
    print("Skipped:", skipped)


if __name__ == "__main__":
    main()
